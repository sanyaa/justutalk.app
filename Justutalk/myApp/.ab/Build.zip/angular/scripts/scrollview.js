/**
 * Created by temp on 18/02/2015.
 */
//angular.module("kendoScrollView", [ ]);